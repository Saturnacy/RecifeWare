#include "intro.h"
#include "font.h"
#include "raylib.h"
#include <math.h>

#define INTRO2_FRAME_W  512
#define INTRO2_FRAME_H  256
#define INTRO2_FRAMES   2

#define FADE_SPEED      160.0f
#define SCENE1_HOLD     3.0f
#define SCENE2_FPS      2.0f

#define SLIDE_SPEED     10.0f
#define CHAR_HOLD       2.5f
#define FLASH_SPEED     600.0f

#define CHAR_SCALE      4.0f
#define NAME_FONT_SIZE  32.0f
#define NAME_SPACING    2.0f

typedef enum {
    INTRO_FADE_IN,
    INTRO_HOLD,
    INTRO_FADE_OUT,
    INTRO_SCENE2,
    INTRO_SEV_IN,
    INTRO_SEV_HOLD,
    INTRO_SEV_OUT,
    INTRO_DUDU_IN,
    INTRO_DUDU_HOLD,
    INTRO_DUDU_OUT,
    INTRO_MEIALUA_IN,
    INTRO_MEIALUA_HOLD,
    INTRO_MEIALUA_OUT,
    INTRO_UBEE_IN,
    INTRO_UBEE_HOLD,
    INTRO_UBEE_OUT,
    INTRO_GALCOB_IN,
    INTRO_GALCOB_HOLD,
    INTRO_FLASH,
    INTRO_FADEOUT_END,
    INTRO_DONE
} IntroPhase;

static void DrawCharSprite(Texture2D tex, int frameW, int frameH, int frame, float cx, float cy, float scale) {
    Rectangle src = { (float)(frame * frameW), 0, (float)frameW, (float)frameH };
    float dw = frameW * scale;
    float dh = frameH * scale;
    Rectangle dst = { cx - dw / 2.0f, cy - dh / 2.0f, dw, dh };
    DrawTexturePro(tex, src, dst, (Vector2){0, 0}, 0.0f, WHITE);
}

static void DrawNameTag(Font f, const char *name, float cx, float spriteTopY, float scale) {
    float fontSize = NAME_FONT_SIZE * (scale / CHAR_SCALE);
    Vector2 sz = MeasureTextEx(f, name, fontSize, NAME_SPACING);
    float tx = cx - sz.x / 2.0f;
    float ty = spriteTopY - sz.y - 8.0f;
    DrawTextEx(f, name, (Vector2){tx, ty}, fontSize, NAME_SPACING, WHITE);
}

void RunIntro(void) {
    int sw = GetScreenWidth();
    int sh = GetScreenHeight();

    Texture2D scene1 = LoadTexture("../assets/sprites/intro/intro1.png");
    Texture2D scene2 = LoadTexture("../assets/sprites/intro/intro2.png");

    Texture2D sevTex  = LoadTexture("../assets/sprites/intro/severino.png");
    Texture2D duduTex = LoadTexture("../assets/sprites/intro/dudu.png");
    Texture2D luaTex  = LoadTexture("../assets/sprites/intro/lua.png");
    Texture2D meiaTex = LoadTexture("../assets/sprites/intro/meia.png");
    Texture2D ubeeTex = LoadTexture("../assets/sprites/intro/ubee.png");
    Texture2D galTex  = LoadTexture("../assets/sprites/intro/galafuz.png");
    Texture2D cobTex  = LoadTexture("../assets/sprites/intro/cobalto.png");

    const int SEV_FW  = sevTex.width  / 2; const int SEV_FH  = sevTex.height;
    const int DUDU_FW = duduTex.width / 2; const int DUDU_FH = duduTex.height;
    const int LUA_FW  = luaTex.width  / 2; const int LUA_FH  = luaTex.height;
    const int MEIA_FW = meiaTex.width / 2; const int MEIA_FH = meiaTex.height;
    const int UBEE_FW = ubeeTex.width / 2; const int UBEE_FH = ubeeTex.height;
    const int GAL_FW  = galTex.width  / 2; const int GAL_FH  = galTex.height;
    const int COB_FW  = cobTex.width  / 2; const int COB_FH  = cobTex.height;

    Font introFont = GetIntroFont();

    IntroPhase phase = INTRO_FADE_IN;
    float alpha      = 0.0f;
    float holdTimer  = 0.0f;
    int   frame      = 0;
    float frameTimer = 0.0f;

    float animFrame  = 0.0f;
    float charTimer  = 0.0f;

    float sevX  = (float)sw + SEV_FW  * CHAR_SCALE;
    float duduX = -(float)(DUDU_FW * CHAR_SCALE);
    float meiaX = (float)sw + MEIA_FW * CHAR_SCALE;
    float luaX  = (float)sw + (MEIA_FW * 2 + LUA_FW) * CHAR_SCALE;
    float ubeeX = (float)sw + UBEE_FW * CHAR_SCALE;
    float galX  = -(float)(GAL_FW  * CHAR_SCALE);
    float cobX  = (float)sw + COB_FW  * CHAR_SCALE;

    float charY  = sh * 0.6f;

    float sevTargetX  = sw * 0.5f;
    float duduTargetX = sw * 0.5f;

    float meiaTargetX = sw * 0.45f;
    float luaTargetX  = sw * 0.6f;

    float ubeeTargetX = sw * 0.5f;

    float galTargetX  = sw * 0.35f;
    float cobTargetX  = sw * 0.65f;

    float flashAlpha    = 0.0f;
    float endFadeAlpha  = 0.0f;

    while (!WindowShouldClose()) {
        float dt = GetFrameTime();

        if (IsKeyPressed(KEY_ESCAPE) || IsKeyPressed(KEY_SPACE) || IsKeyPressed(KEY_ENTER))
            break;

        animFrame += dt * 2.0f;
        int sprFrame = (int)animFrame % 2;

        switch (phase) {
            case INTRO_FADE_IN:
                alpha += FADE_SPEED * dt;
                if (alpha >= 255.0f) { alpha = 255.0f; phase = INTRO_HOLD; }
                break;

            case INTRO_HOLD:
                holdTimer += dt;
                if (holdTimer >= SCENE1_HOLD) phase = INTRO_FADE_OUT;
                break;

            case INTRO_FADE_OUT:
                alpha -= FADE_SPEED * dt;
                if (alpha <= 0.0f) { alpha = 0.0f; phase = INTRO_SCENE2; frame = 0; frameTimer = 0.0f; }
                break;

            case INTRO_SCENE2:
                frameTimer += dt;
                if (frameTimer >= 1.0f / SCENE2_FPS) {
                    frameTimer = 0.0f;
                    frame++;
                    if (frame >= INTRO2_FRAMES) {
                        phase = INTRO_SEV_IN;
                        sevX = (float)sw + SEV_FW * CHAR_SCALE;
                    }
                }
                break;

            case INTRO_SEV_IN:
                sevX += (sevTargetX - sevX) * SLIDE_SPEED * dt;
                if (sevX >= sevTargetX - 1.0f) { sevX = sevTargetX; charTimer = 0.0f; phase = INTRO_SEV_HOLD; }
                break;

            case INTRO_SEV_HOLD:
                charTimer += dt;
                if (charTimer >= CHAR_HOLD) phase = INTRO_SEV_OUT;
                break;

            case INTRO_SEV_OUT:
                sevX += ((float)sw + SEV_FW * CHAR_SCALE - sevX) * SLIDE_SPEED * dt;
                if (sevX >= (float)sw + SEV_FW * CHAR_SCALE - 1.0f) {
                    sevX = (float)sw + SEV_FW * CHAR_SCALE;
                    duduX = -(float)(DUDU_FW * CHAR_SCALE);
                    phase = INTRO_DUDU_IN;
                }
                break;

            case INTRO_DUDU_IN:
                duduX += (duduTargetX - duduX) * SLIDE_SPEED * dt;
                if (duduX >= duduTargetX - 1.0f) { duduX = duduTargetX; charTimer = 0.0f; phase = INTRO_DUDU_HOLD; }
                break;

            case INTRO_DUDU_HOLD:
                charTimer += dt;
                if (charTimer >= CHAR_HOLD) phase = INTRO_DUDU_OUT;
                break;

            case INTRO_DUDU_OUT:
                duduX += (-(float)(DUDU_FW * CHAR_SCALE) - duduX) * SLIDE_SPEED * dt;
                if (duduX <= -(float)(DUDU_FW * CHAR_SCALE) + 1.0f) {
                    duduX = -(float)(DUDU_FW * CHAR_SCALE);
                    meiaX = (float)sw + MEIA_FW * CHAR_SCALE;
                    luaX  = (float)sw + (MEIA_FW * 2 + LUA_FW) * CHAR_SCALE;
                    phase = INTRO_MEIALUA_IN;
                }
                break;

            case INTRO_MEIALUA_IN:
                meiaX += (meiaTargetX - meiaX) * SLIDE_SPEED * dt;
                luaX  += (luaTargetX  - luaX)  * SLIDE_SPEED * dt;
                if (meiaX >= meiaTargetX - 1.0f) {
                    meiaX = meiaTargetX; luaX = luaTargetX;
                    charTimer = 0.0f; phase = INTRO_MEIALUA_HOLD;
                }
                break;

            case INTRO_MEIALUA_HOLD:
                charTimer += dt;
                if (charTimer >= CHAR_HOLD) phase = INTRO_MEIALUA_OUT;
                break;

            case INTRO_MEIALUA_OUT:
                meiaX += ((float)sw + MEIA_FW * CHAR_SCALE - meiaX) * SLIDE_SPEED * dt;
                luaX  += ((float)sw + LUA_FW  * CHAR_SCALE - luaX)  * SLIDE_SPEED * dt;
                if (meiaX >= (float)sw + MEIA_FW * CHAR_SCALE - 1.0f) {
                    meiaX = (float)sw; luaX = (float)sw;
                    ubeeX = (float)sw + UBEE_FW * CHAR_SCALE;
                    phase = INTRO_UBEE_IN;
                }
                break;

            case INTRO_UBEE_IN:
                ubeeX += (ubeeTargetX - ubeeX) * SLIDE_SPEED * dt;
                if (ubeeX >= ubeeTargetX - 1.0f) { ubeeX = ubeeTargetX; charTimer = 0.0f; phase = INTRO_UBEE_HOLD; }
                break;

            case INTRO_UBEE_HOLD:
                charTimer += dt;
                if (charTimer >= CHAR_HOLD) phase = INTRO_UBEE_OUT;
                break;

            case INTRO_UBEE_OUT:
                ubeeX += ((float)sw + UBEE_FW * CHAR_SCALE - ubeeX) * SLIDE_SPEED * dt;
                if (ubeeX >= (float)sw + UBEE_FW * CHAR_SCALE - 1.0f) {
                    ubeeX = (float)sw + UBEE_FW * CHAR_SCALE;
                    galX = -(float)(GAL_FW * CHAR_SCALE);
                    cobX = (float)sw + COB_FW * CHAR_SCALE;
                    phase = INTRO_GALCOB_IN;
                }
                break;

            case INTRO_GALCOB_IN:
                galX += (galTargetX - galX) * SLIDE_SPEED * dt;
                cobX += (cobTargetX - cobX) * SLIDE_SPEED * dt;
                if (galX >= galTargetX - 1.0f) {
                    galX = galTargetX; cobX = cobTargetX;
                    charTimer = 0.0f; phase = INTRO_GALCOB_HOLD;
                }
                break;

            case INTRO_GALCOB_HOLD:
                charTimer += dt;
                if (charTimer >= CHAR_HOLD) { flashAlpha = 0.0f; phase = INTRO_FLASH; }
                break;

            case INTRO_FLASH:
                flashAlpha += FLASH_SPEED * dt;
                if (flashAlpha >= 255.0f) { flashAlpha = 255.0f; endFadeAlpha = 0.0f; phase = INTRO_FADEOUT_END; }
                break;

            case INTRO_FADEOUT_END:
                endFadeAlpha += FADE_SPEED * dt;
                if (endFadeAlpha >= 255.0f) { phase = INTRO_DONE; }
                break;

            case INTRO_DONE:
                goto cleanup;
        }

        float scale = (float)sw / INTRO2_FRAME_W;
        float dstW  = INTRO2_FRAME_W * scale;
        float dstH  = INTRO2_FRAME_H * scale;
        float dstX  = (sw - dstW) / 2.0f;
        float dstY  = (sh - dstH) / 2.0f;

        BeginDrawing();
        ClearBackground(BLACK);

        if (phase == INTRO_FADE_IN || phase == INTRO_HOLD || phase == INTRO_FADE_OUT) {
            DrawTexturePro(scene1,
                (Rectangle){ 0, 0, INTRO2_FRAME_W, INTRO2_FRAME_H },
                (Rectangle){ dstX, dstY, dstW, dstH },
                (Vector2){ 0, 0 }, 0.0f, Fade(WHITE, alpha / 255.0f));

        } else if (phase == INTRO_SCENE2) {
            int cf = frame < INTRO2_FRAMES ? frame : INTRO2_FRAMES - 1;
            DrawTexturePro(scene2,
                (Rectangle){ 0, cf * INTRO2_FRAME_H, INTRO2_FRAME_W, INTRO2_FRAME_H },
                (Rectangle){ dstX, dstY, dstW, dstH },
                (Vector2){ 0, 0 }, 0.0f, WHITE);

        } else {
            if (phase == INTRO_SEV_IN || phase == INTRO_SEV_HOLD || phase == INTRO_SEV_OUT) {
                float dh = SEV_FH * CHAR_SCALE;
                float topY = charY - dh / 2.0f;
                DrawCharSprite(sevTex, SEV_FW, SEV_FH, sprFrame, sevX, charY, CHAR_SCALE);
                DrawNameTag(introFont, "SEVERINO", sevX, topY, CHAR_SCALE);
            }

            if (phase == INTRO_DUDU_IN || phase == INTRO_DUDU_HOLD || phase == INTRO_DUDU_OUT) {
                float dh = DUDU_FH * CHAR_SCALE;
                float topY = charY - dh / 2.0f;
                DrawCharSprite(duduTex, DUDU_FW, DUDU_FH, sprFrame, duduX, charY, CHAR_SCALE);
                DrawNameTag(introFont, "DUDU", duduX, topY, CHAR_SCALE);
            }

            if (phase == INTRO_MEIALUA_IN || phase == INTRO_MEIALUA_HOLD || phase == INTRO_MEIALUA_OUT) {
                float meiaH = MEIA_FH * CHAR_SCALE;
                float luaH  = LUA_FH  * CHAR_SCALE;
                float meiaTopY = charY - meiaH / 2.0f;
                float luaTopY  = charY - luaH  / 2.0f;
                float nameCX = (meiaX + luaX) / 2.0f;
                float nameTopY = fminf(meiaTopY, luaTopY);
                DrawCharSprite(meiaTex, MEIA_FW, MEIA_FH, sprFrame, meiaX, charY, CHAR_SCALE);
                DrawCharSprite(luaTex,  LUA_FW,  LUA_FH,  sprFrame, luaX,  charY, CHAR_SCALE);
                DrawNameTag(introFont, "MEIA E LUA", nameCX, nameTopY, CHAR_SCALE);
            }

            if (phase == INTRO_UBEE_IN || phase == INTRO_UBEE_HOLD || phase == INTRO_UBEE_OUT) {
                float dh = UBEE_FH * CHAR_SCALE;
                float topY = charY - dh / 2.0f;
                DrawCharSprite(ubeeTex, UBEE_FW, UBEE_FH, sprFrame, ubeeX, charY, CHAR_SCALE);
                DrawNameTag(introFont, "U-BEE", ubeeX, topY, CHAR_SCALE);
            }

            if (phase == INTRO_GALCOB_IN || phase == INTRO_GALCOB_HOLD ||
                phase == INTRO_FLASH || phase == INTRO_FADEOUT_END) {
                float galH = GAL_FH * CHAR_SCALE;
                float cobH = COB_FH * CHAR_SCALE;
                float galTopY = charY - galH / 2.0f;
                float cobTopY = charY - cobH / 2.0f;
                DrawCharSprite(galTex, GAL_FW, GAL_FH, sprFrame, galX, charY, CHAR_SCALE);
                DrawCharSprite(cobTex, COB_FW, COB_FH, sprFrame, cobX, charY, CHAR_SCALE);
                DrawNameTag(introFont, "GALAFUZ",  galX, galTopY, CHAR_SCALE);
                DrawNameTag(introFont, "COBALTO",  cobX, cobTopY, CHAR_SCALE);
            }

            if (phase == INTRO_FLASH || phase == INTRO_FADEOUT_END) {
                float fa = (phase == INTRO_FLASH) ? flashAlpha : 255.0f;
                DrawRectangle(0, 0, sw, sh, Fade(WHITE, fa / 255.0f));
            }
            if (phase == INTRO_FADEOUT_END) {
                DrawRectangle(0, 0, sw, sh, Fade(BLACK, endFadeAlpha / 255.0f));
            }
        }

        EndDrawing();
    }

cleanup:
    UnloadTexture(scene1);
    UnloadTexture(scene2);
    UnloadTexture(sevTex);
    UnloadTexture(duduTex);
    UnloadTexture(luaTex);
    UnloadTexture(meiaTex);
    UnloadTexture(ubeeTex);
    UnloadTexture(galTex);
    UnloadTexture(cobTex);
}